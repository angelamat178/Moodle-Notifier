import requests
from config import MOODLE_URL, MOODLE_USERNAME, MOODLE_PASSWORD

_token = None


def get_token():
    """Obtiene o reutiliza el token de autenticación."""
    global _token
    if _token:
        return _token

    url = f"{MOODLE_URL}/login/token.php"
    resp = requests.post(url, data={
        "username": MOODLE_USERNAME,
        "password": MOODLE_PASSWORD,
        "service": "moodle_mobile_app"
    }, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    if "token" not in data:
        raise Exception(f"Error al obtener token: {data.get('error', data)}")

    _token = data["token"]
    return _token


def call_api(function_name, **params):
    """Llama a un endpoint de la API REST de Moodle."""
    token = get_token()
    url = f"{MOODLE_URL}/webservice/rest/server.php"
    payload = {
        "wstoken": token,
        "wsfunction": function_name,
        "moodlewsrestformat": "json",
        **params
    }
    resp = requests.post(url, data=payload, timeout=15)
    resp.raise_for_status()
    return resp.json()


def get_courses():
    """Devuelve los cursos en los que está matriculado el usuario."""
    user_info = call_api("core_webservice_get_site_info")
    user_id = user_info["userid"]
    courses = call_api("core_enrol_get_users_courses", userid=user_id)
    return courses


def get_assignments(course_ids):
    """
    Devuelve todas las tareas con fecha límite de los cursos dados.
    Retorna lista de dicts con: id, name, duedate, coursename, cmid
    """
    if not course_ids:
        return []

    # Construir parámetros courseids[0]=X&courseids[1]=Y...
    params = {f"courseids[{i}]": cid for i, cid in enumerate(course_ids)}
    result = call_api("mod_assign_get_assignments", **params)

    assignments = []
    for course in result.get("courses", []):
        for assign in course.get("assignments", []):
            if assign.get("duedate", 0) > 0:
                assignments.append({
                    "id": assign["id"],
                    "cmid": assign["cmid"],
                    "name": assign["name"],
                    "duedate": assign["duedate"],
                    "coursename": course["fullname"],
                    "course_id": course["id"]
                })
    return assignments


def get_submission_status(assignment_id):
    """
    Devuelve True si la tarea ya ha sido entregada por el usuario.
    """
    try:
        result = call_api(
            "mod_assign_get_submission_status",
            assignid=assignment_id
        )
        submission = result.get("lastattempt", {}).get("submission", {})
        status = submission.get("status", "")
        return status in ("submitted", "graded")
    except Exception:
        return False


def reset_token():
    """Fuerza la renovación del token en la próxima llamada."""
    global _token
    _token = None
