from plyer import notification


def notify(title: str, message: str, duration: int = 8):
    """Muestra una notificación nativa de Windows."""
    notification.notify(
        title=title,
        message=message,
        app_name="Moodle Notifier",
        timeout=duration
    )


def notify_deadline(assignment_name: str, course_name: str, minutes_left: int):
    """Notificación de tiempo restante para una tarea."""
    if minutes_left >= 60:
        hours = minutes_left // 60
        time_str = f"{hours} hora{'s' if hours > 1 else ''}"
    else:
        time_str = f"{minutes_left} minutos"

    urgency = ""
    if minutes_left <= 10:
        urgency = "⚠️ URGENTE - "
    elif minutes_left <= 30:
        urgency = "🔴 "
    elif minutes_left <= 60:
        urgency = "🟠 "
    else:
        urgency = "🟡 "

    title = f"{urgency}Moodle: quedan {time_str}"
    message = f"{assignment_name}\n{course_name}"
    notify(title, message, duration=10 if minutes_left <= 30 else 7)


def notify_submitted(assignment_name: str, course_name: str):
    """Notificación de tarea entregada."""
    title = "✅ Tarea entregada"
    message = f"{assignment_name}\n{course_name}"
    notify(title, message, duration=6)
