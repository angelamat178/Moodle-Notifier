@echo off
echo ============================================
echo   Instalando Moodle Notifier...
echo ============================================
echo.

:: Comprobar que Python está instalado
python --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [ERROR] Python no está instalado o no está en el PATH.
    echo Descárgalo desde https://www.python.org/downloads/
    echo Asegúrate de marcar "Add Python to PATH" al instalar.
    pause
    exit /b 1
)

echo [OK] Python encontrado.
echo.
echo Instalando dependencias...
pip install requests plyer

echo.
echo ============================================
echo   Instalación completada.
echo   Ahora edita config.py con tu usuario
echo   y contraseña de Moodle antes de ejecutar.
echo ============================================
pause
