import time
import logging
from datetime import datetime

import moodle_api
import notifier
import tracker
from config import NOTIFICATION_THRESHOLDS, CHECK_INTERVAL_MINUTES

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    filename="moodle_notifier.log",
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
log = logging.getLogger(__name__)


def check_assignments():
    """Consulta Moodle y procesa las notificaciones necesarias."""
    now = datetime.now().timestamp()

    log.info("Iniciando comprobación...")

    try:
        courses = moodle_api.get_courses()
        course_ids = [c["id"] for c in courses]
        assignments = moodle_api.get_assignments(course_ids)
    except Exception as e:
        log.error(f"Error al obtener datos de Moodle: {e}")
        moodle_api.reset_token()
        return

    log.info(f"Tareas con fecha límite encontradas: {len(assignments)}")
    tracker.cleanup_old_entries([a["id"] for a in assignments])

    for assign in assignments:
        aid = assign["id"]
        name = assign["name"]
        course = assign["coursename"]
        duedate = assign["duedate"]
        minutes_left = int((duedate - now) / 60)

        # ── Comprobar si ya fue entregada ─────────────────────────────────
        if not tracker.was_submitted_notified(aid):
            try:
                submitted = moodle_api.get_submission_status(aid)
            except Exception:
                submitted = False

            if submitted:
                log.info(f"[ENTREGADA] {name}")
                notifier.notify_submitted(name, course)
                tracker.mark_submitted_notified(aid)
                continue  # No hace falta comprobar umbrales

        # ── Ignorar tareas pasadas o ya entregadas ────────────────────────
        if minutes_left < 0:
            log.debug(f"[PASADA] {name} (hace {-minutes_left} min)")
            continue

        # ── Comprobar umbrales de tiempo ──────────────────────────────────
        for threshold in sorted(NOTIFICATION_THRESHOLDS):
            if minutes_left <= threshold:
                if not tracker.was_notified(aid, threshold):
                    log.info(f"[NOTIF {threshold}min] {name} — quedan {minutes_left} min")
                    notifier.notify_deadline(name, course, threshold)
                    tracker.mark_notified(aid, threshold)


def main():
    log.info("=" * 60)
    log.info("Moodle Notifier arrancado")
    log.info("=" * 60)

    print("✅ Moodle Notifier en ejecución. Minimiza esta ventana.")
    print(f"   Comprobando cada {CHECK_INTERVAL_MINUTES} minutos.")
    print("   Revisa moodle_notifier.log para ver la actividad.\n")

    while True:
        try:
            check_assignments()
        except Exception as e:
            log.exception(f"Error inesperado en el bucle principal: {e}")

        next_check = datetime.now().strftime("%H:%M:%S")
        print(f"[{next_check}] Comprobación completada. Próxima en {CHECK_INTERVAL_MINUTES} min.")
        time.sleep(CHECK_INTERVAL_MINUTES * 60)


if __name__ == "__main__":
    main()
