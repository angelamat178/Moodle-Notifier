# ============================================================
#  CONFIGURACIÓN - Edita solo este archivo
# ============================================================

MOODLE_URL = "https://your-moodle-instance.com/moodle"

# Pon aquí tu usuario y contraseña de Moodle
MOODLE_USERNAME = ""
MOODLE_PASSWORD = ""

# Umbrales de notificación en minutos
NOTIFICATION_THRESHOLDS = [720, 360, 60, 30, 10]  # 12h, 6h, 1h, 30min, 10min

# Cada cuántos minutos se comprueba Moodle (recomendado: 5)
CHECK_INTERVAL_MINUTES = 5

# Archivo donde se guarda el estado de notificaciones enviadas
STATE_FILE = "notifier_state.json"
