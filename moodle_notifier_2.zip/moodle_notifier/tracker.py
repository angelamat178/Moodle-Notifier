import json
import os
from config import STATE_FILE


def _load() -> dict:
    if not os.path.exists(STATE_FILE):
        return {}
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(state: dict):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def was_notified(assignment_id: int, threshold_minutes: int) -> bool:
    """Devuelve True si ya se envió la notificación para este umbral."""
    state = _load()
    key = str(assignment_id)
    sent = state.get(key, {}).get("sent_thresholds", [])
    return threshold_minutes in sent


def mark_notified(assignment_id: int, threshold_minutes: int):
    """Marca un umbral como notificado."""
    state = _load()
    key = str(assignment_id)
    if key not in state:
        state[key] = {"sent_thresholds": [], "submitted_notified": False}
    if threshold_minutes not in state[key]["sent_thresholds"]:
        state[key]["sent_thresholds"].append(threshold_minutes)
    _save(state)


def was_submitted_notified(assignment_id: int) -> bool:
    """Devuelve True si ya se notificó la entrega de esta tarea."""
    state = _load()
    return state.get(str(assignment_id), {}).get("submitted_notified", False)


def mark_submitted_notified(assignment_id: int):
    """Marca la tarea como notificada por entrega."""
    state = _load()
    key = str(assignment_id)
    if key not in state:
        state[key] = {"sent_thresholds": [], "submitted_notified": False}
    state[key]["submitted_notified"] = True
    _save(state)


def cleanup_old_entries(active_ids: list):
    """Elimina del estado tareas que ya no existen en Moodle."""
    state = _load()
    active_keys = {str(i) for i in active_ids}
    keys_to_delete = [k for k in state if k not in active_keys]
    for k in keys_to_delete:
        del state[k]
    if keys_to_delete:
        _save(state)
