@echo off
cd /d "%~dp0"
echo Iniciando Moodle Notifier...
python main.py
pause
